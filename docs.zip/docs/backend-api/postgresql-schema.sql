-- PostgreSQL starter schema for SIS Dashboard
-- Target: PostgreSQL 15+
--
-- Notes:
-- 1. Enum values use lower_snake_case.
-- 2. The schema is normalized; nested frontend response objects should be assembled in the API layer.
-- 3. `updated_at` columns are included, but update triggers are intentionally omitted for simplicity.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- =========================================================
-- Enum Types
-- =========================================================

CREATE TYPE user_admin_status AS ENUM ('active', 'invited', 'inactive');
CREATE TYPE audit_severity AS ENUM ('info', 'warning', 'critical');
CREATE TYPE notification_channel AS ENUM ('email', 'sms', 'in_app');
CREATE TYPE integration_connection_status AS ENUM ('connected', 'disconnected', 'needs_attention');
CREATE TYPE backup_job_type AS ENUM ('backup', 'export', 'import', 'migration');
CREATE TYPE backup_job_status AS ENUM ('completed', 'running', 'failed');

CREATE TYPE lead_channel AS ENUM ('in_app', 'referral', 'walk_in', 'other');
CREATE TYPE lead_status AS ENUM ('new', 'contacted', 'converted', 'closed');
CREATE TYPE admission_activity_type AS ENUM ('call', 'message', 'meeting', 'note', 'status_change');
CREATE TYPE application_source AS ENUM ('in_app', 'referral', 'walk_in', 'other');
CREATE TYPE application_status AS ENUM (
    'draft',
    'submitted',
    'under_review',
    'test_scheduled',
    'interview_scheduled',
    'waitlisted',
    'accepted',
    'rejected'
);
CREATE TYPE decision_type AS ENUM ('accept', 'waitlist', 'reject');
CREATE TYPE application_test_status AS ENUM ('scheduled', 'completed', 'cancelled');
CREATE TYPE application_interview_status AS ENUM ('scheduled', 'completed', 'cancelled');
CREATE TYPE document_status AS ENUM ('complete', 'missing');

CREATE TYPE student_status AS ENUM ('active', 'suspended', 'withdrawn', 'graduated');
CREATE TYPE note_category AS ENUM ('academic', 'behavioral', 'medical', 'general');
CREATE TYPE note_visibility AS ENUM ('visible_to_guardian', 'internal');
CREATE TYPE enrollment_status AS ENUM ('active', 'completed', 'withdrawn');
CREATE TYPE enrollment_movement_action AS ENUM (
    'enrolled',
    'transferred_internal',
    'transferred_external',
    'withdrawn',
    'promoted',
    'reassigned_bulk'
);

CREATE TYPE entity_scope_type AS ENUM ('school', 'stage', 'grade', 'section', 'classroom');
CREATE TYPE room_type AS ENUM ('classroom', 'lab', 'other');
CREATE TYPE academic_event_type AS ENUM ('holiday', 'exam', 'activity', 'other');
CREATE TYPE timetable_config_scope AS ENUM ('term', 'grade', 'section', 'classroom');
CREATE TYPE timetable_slot_type AS ENUM ('class', 'break');
CREATE TYPE timetable_entry_status AS ENUM ('draft', 'published');
CREATE TYPE lesson_status AS ENUM ('planned', 'done');
CREATE TYPE attachment_type AS ENUM ('file', 'link');
CREATE TYPE video_type AS ENUM ('upload', 'link');
CREATE TYPE lesson_plan_item_status AS ENUM ('planned', 'in_progress', 'done', 'skipped');

CREATE TYPE attendance_mode AS ENUM ('daily', 'period');
CREATE TYPE daily_computation_strategy AS ENUM ('manual', 'derived_from_periods');
CREATE TYPE attendance_session_status AS ENUM ('draft', 'submitted');
CREATE TYPE attendance_status AS ENUM ('present', 'absent', 'late', 'excused', 'early_leave', 'unmarked');
CREATE TYPE excuse_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE excuse_type AS ENUM ('absence', 'late', 'early_leave');

CREATE TYPE assessment_type AS ENUM (
    'quiz',
    'month_exam',
    'midterm',
    'term_exam',
    'assignment',
    'final',
    'practical'
);
CREATE TYPE assessment_delivery_mode AS ENUM ('score_only', 'question_based');
CREATE TYPE assessment_approval_status AS ENUM ('draft', 'published', 'approved');
CREATE TYPE grade_item_status AS ENUM ('entered', 'missing', 'absent');
CREATE TYPE assessment_question_type AS ENUM (
    'mcq_single',
    'mcq_multi',
    'true_false',
    'short_answer',
    'essay'
);
CREATE TYPE assessment_submission_status AS ENUM ('not_started', 'submitted', 'in_progress', 'corrected');
CREATE TYPE assessment_correction_status AS ENUM ('pending', 'corrected');
CREATE TYPE grade_rule_scope AS ENUM ('school', 'grade');

CREATE TYPE reinforcement_source AS ENUM ('teacher', 'parent', 'system');
CREATE TYPE reinforcement_status AS ENUM (
    'draft',
    'active',
    'in_progress',
    'under_review',
    'completed',
    'rejected',
    'archived'
);
CREATE TYPE reinforcement_proof_type AS ENUM ('image', 'video', 'document', 'none');
CREATE TYPE reinforcement_reward_type AS ENUM ('moral', 'financial', 'xp', 'badge');

-- =========================================================
-- Core / Settings
-- =========================================================

CREATE TABLE schools (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT NOT NULL UNIQUE,
    school_name TEXT NOT NULL,
    short_name TEXT,
    timezone TEXT NOT NULL DEFAULT 'Africa/Cairo',
    address_line TEXT,
    formatted_address TEXT,
    city TEXT,
    country TEXT,
    footer_signature TEXT,
    logo_url TEXT,
    latitude NUMERIC(9, 6),
    longitude NUMERIC(9, 6),
    map_place_label TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email CITEXT NOT NULL,
    password_hash TEXT,
    status user_admin_status NOT NULL DEFAULT 'invited',
    last_active_at TIMESTAMPTZ,
    invited_at TIMESTAMPTZ,
    last_invite_sent_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (school_id, email)
);

CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    is_system BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (school_id, name)
);

CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    permission_key TEXT NOT NULL UNIQUE,
    module_key TEXT NOT NULL,
    action_key TEXT NOT NULL,
    label TEXT NOT NULL,
    description TEXT
);

CREATE TABLE role_permissions (
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE user_roles (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
    uploaded_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    storage_provider TEXT NOT NULL,
    storage_bucket TEXT,
    storage_key TEXT NOT NULL,
    file_name TEXT NOT NULL,
    mime_type TEXT,
    size_bytes BIGINT,
    checksum_sha256 TEXT,
    public_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
    actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    actor_name TEXT,
    action_label TEXT NOT NULL,
    module_key TEXT NOT NULL,
    entity_type TEXT,
    entity_id UUID,
    severity audit_severity NOT NULL DEFAULT 'info',
    ip_address INET,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE school_policy_settings (
    school_id UUID PRIMARY KEY REFERENCES schools(id) ON DELETE CASCADE,
    attendance_mode attendance_mode NOT NULL DEFAULT 'daily',
    attendance_requires_reason BOOLEAN NOT NULL DEFAULT TRUE,
    late_threshold_minutes INTEGER NOT NULL DEFAULT 5,
    early_leave_threshold_minutes INTEGER NOT NULL DEFAULT 5,
    grade_pass_mark NUMERIC(5, 2) NOT NULL DEFAULT 50,
    allow_teacher_grade_override BOOLEAN NOT NULL DEFAULT FALSE,
    behavior_points_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
